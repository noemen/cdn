// JavaScript Document
(function($){
$(document).ready(function(e) {

});//ready
})(jQuery);