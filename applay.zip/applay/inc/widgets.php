<?php
/*
 * Include widgets
 */

include('widgets/latest-post-type.php');
?>